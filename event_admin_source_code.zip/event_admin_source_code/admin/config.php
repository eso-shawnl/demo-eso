<?php

// HTTP
define('HTTP_SERVER', 'http://' . $_SERVER['HTTP_HOST'] . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/.\\') . '/');
define('HTTPS_SERVER', 'http://' . $_SERVER['HTTP_HOST'] . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/.\\') . '/');
define('HTTP_CATALOG', 'http://event15.3a.nz/');
define('HTTPS_CATALOG', 'http://event15.3a.nz/');
// DIR

define('DIR_APPLICATION', '/volumes/data/eso-s1/event_admin_source_code/admin/');
define('DIR_SYSTEM', '/volumes/data/eso-s1/event_admin_source_code/system/');
define('DIR_LANGUAGE', '/volumes/data/eso-s1/event_admin_source_code/admin/language/');
define('DIR_TEMPLATE', '/volumes/data/eso-s1/event_admin_source_code/admin/view/template/');
define('DIR_CONFIG', '/volumes/data/eso-s1/event_admin_source_code/system/config/');
define('DIR_IMAGE', '/volumes/data/eso-s1/event_admin_source_code/image/');
define('DIR_CACHE', '/volumes/data/eso-s1/event_admin_source_code/system/cache/');
define('DIR_DOWNLOAD', '/volumes/data/eso-s1/event_admin_source_code/system/download/');
define('DIR_UPLOAD', '/volumes/data/eso-s1/event_admin_source_code/system/upload/');
define('DIR_LOGS', '/volumes/data/eso-s1/event_admin_source_code/system/logs/');
define('DIR_MODIFICATION', '/volumes/data/eso-s1/event_admin_source_code/system/modification/');
define('DIR_CATALOG', '/volumes/data/eso-s1/event_admin_source_code/catalog/');

define('LANG', 'admin');


// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', '3a_events_op');
define('DB_PASSWORD', '3a_events_op');
define('DB_DATABASE', '3a_events_op');
define('DB_PREFIX', '3a_');
